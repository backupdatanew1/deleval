exports.handler = async (event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};

const csvParser = require("csv-parser");
const fs = require("fs")
let farm = []
async function accessFarm(key, value) {
  let fa = farm.filter((obj) => obj[key] == value);
  console.log(fa);
}
fs.createReadStream("./read.csv")
  .pipe(csvParser({ separator: "," }))
  .on("data", (data) => farm.push(data))
  .on("end", async function () {
    //console.log(farm);
    await accessFarm("farm_name", "rajwada");
  });
