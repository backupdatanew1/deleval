module.exports = dependencies => async function (event, context) {
    const farm_id = event.pathParameters.id;
    let response =    await fetch(farm_id,dependencies.ddb)
    console.log(response);
    return sendResponse(200,response)
    
}

function fetch(farm_id,ddb) {
    let param = {
        TableName: "CSVData",
        Key :{farm_id:farm_id}
    };
    return ddb.get(param).promise();
}

const sendResponse = (status, response) => {
    var response1 = {
        statusCode: status,
        
        body: JSON.stringify(response)
    };
    console.log(response)
    return response1;
};