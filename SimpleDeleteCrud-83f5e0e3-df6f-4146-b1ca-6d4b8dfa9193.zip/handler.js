module.exports = dependencies => async function (event, context) {
    console.log(event)
    let response = await del(event.pathParameters.id,dependencies.ddb)
   // let response = await del("3",dependencies.ddb)
   const response1 = {
        statusCode: 204,
        body: JSON.stringify('success'),
    };
    return response1;
}

function del(farm_id ,ddb) {
    return ddb.delete({
        TableName: "CSVData",
         Key: {
        farm_id: farm_id, 
         },
    }).promise();
}


