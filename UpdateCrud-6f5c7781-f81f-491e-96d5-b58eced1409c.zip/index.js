const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
  let body;
  
  let statusCode = 200;
  // const headers = {
  //   "Content-Type": "application/json"
  // };
    let requestJSON = JSON.parse(event.body);
     const res=   await dynamo
          .put({
            TableName: "CSVData",
            Item: {
              farm_id: requestJSON.farm_id,
              farm_name: requestJSON.farm_name,
              city: requestJSON.city,
              lat: requestJSON.lat,
              long:requestJSON.long,
              county:requestJSON.county
            }
          })
          .promise();
         
          const response = {
        statusCode: 201,
headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
 },


        body: JSON.stringify('success-'),
    };
    return response;
  // return {
  //   statusCode,
  //   res,
  // // headers
  // };
};