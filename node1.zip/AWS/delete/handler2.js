module.exports = dependencies => async function (event, context) {
  let response = await del(5,dependencies.ddb)
  console.log(response);
return JSON.stringify(response)    
}

function del(farm_id,ddb) {
  return ddb.delete({
      TableName: "BasicCrud",
       Key: {
      farm_id: farm_id, 
       },
  }).promise();
}
