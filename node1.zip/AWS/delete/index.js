const AWS = require("aws-sdk");
module.exports.handler = require("./hendler2")({
    ddb:new AWS.DynamoDB.DocumentClient(),
});