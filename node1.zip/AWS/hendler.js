module.exports = dependencies => async function (event , context) {
    let response = await fetch(1,dependencies.ddb)
    console.log(response);
    return JSON.stringify(response)
}
function fetch(farm_id,ddb) {
    let params = {
        TableName: "BasicCrud",
        KeyConditionExpression: "#farm_id = :farm_id",
        ExpressionAttributeNames: {
            "#farm_id": "farm_id"
        } ,
        ExpressionAttributeValues: {
            ":farm_id": farm_id
        }
    };
    return ddb.query(params).promise();
}