const AWS = require("aws-sdk");
module.exports.handler = require("./hendler")({
    ddb:new AWS.DynamoDB.DocumentClient(),
});