module.exports = dependencies => async function (event , context) {
    let item = {
        "farm_id": 4,
        "farn_name": "Malhar Mega Mart",
        "lat":789,
        "long":987
    }
    let response =await SVGAElement(item,dependencies.ddb)
    console.log(response)
    return JSON.stringify(response)
}
 function save(item,ddb) {
    return ddb.put({
        TableName:"BasicCrud",
        Item: item,
    }).promise();
 }