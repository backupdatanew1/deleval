const AWS = require("aws-sdk");
module.exports.handler = require("./hendler1")({
    ddb:new AWS.DynamoDB.DocumentClient(),
});